import RecordReference from './references/record';
import BelongsToReference from './references/belongs-to';
import HasManyReference from './references/has-many';

export { RecordReference, BelongsToReference, HasManyReference };