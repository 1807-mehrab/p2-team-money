QUnit.test('test-helper.js', function(assert) {
  assert.expect(1);
  assert.ok(true, 'test-helper.js should pass ESLint\n\n');
});
