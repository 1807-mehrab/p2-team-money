define("ember-bootstrap/templates/components/bs-tab/pane", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "c8Xih854", "block": "{\"symbols\":[\"&default\"],\"statements\":[[14,1],[0,\"\\n\"]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-tab/pane.hbs" } });
});