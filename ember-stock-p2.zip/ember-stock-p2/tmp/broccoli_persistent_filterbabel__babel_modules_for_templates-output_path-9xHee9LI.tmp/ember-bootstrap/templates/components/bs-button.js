define("ember-bootstrap/templates/components/bs-button", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "qobO3OmX", "block": "{\"symbols\":[\"&default\"],\"statements\":[[4,\"if\",[[23,[\"icon\"]]],null,{\"statements\":[[7,\"i\"],[12,\"class\",[28,[[21,\"icon\"]]]],[9],[10],[0,\" \"]],\"parameters\":[]},null],[1,[21,\"text\"],false],[14,1]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-button.hbs" } });
});