define("ember-bootstrap/templates/components/bs-accordion", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "Y1+9eW0x", "block": "{\"symbols\":[\"&default\"],\"statements\":[[14,1,[[27,\"hash\",null,[[\"item\",\"change\"],[[27,\"component\",[\"bs-accordion/item\"],[[\"selected\",\"onClick\"],[[23,[\"isSelected\"]],[27,\"action\",[[22,0,[]],\"change\"],null]]]],[27,\"action\",[[22,0,[]],\"change\"],null]]]]]]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-accordion.hbs" } });
});