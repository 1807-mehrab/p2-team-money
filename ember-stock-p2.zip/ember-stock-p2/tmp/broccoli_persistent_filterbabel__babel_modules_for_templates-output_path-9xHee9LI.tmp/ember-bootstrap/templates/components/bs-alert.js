define("ember-bootstrap/templates/components/bs-alert", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "lmPhVYaS", "block": "{\"symbols\":[\"&default\"],\"statements\":[[4,\"unless\",[[23,[\"hidden\"]]],null,{\"statements\":[[4,\"if\",[[23,[\"dismissible\"]]],null,{\"statements\":[[0,\"    \"],[7,\"button\"],[11,\"class\",\"close\"],[11,\"aria-label\",\"Close\"],[11,\"type\",\"button\"],[3,\"action\",[[22,0,[]],\"dismiss\"]],[9],[0,\"\\n      \"],[7,\"span\"],[11,\"aria-hidden\",\"true\"],[9],[0,\"×\"],[10],[0,\"\\n    \"],[10],[0,\"\\n\"]],\"parameters\":[]},null],[0,\"  \"],[14,1],[0,\"\\n\"]],\"parameters\":[]},null]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-alert.hbs" } });
});