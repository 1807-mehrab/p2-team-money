define("ember-bootstrap/templates/components/bs-carousel/slide", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "VBapCW4f", "block": "{\"symbols\":[\"&default\"],\"statements\":[[14,1]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-carousel/slide.hbs" } });
});