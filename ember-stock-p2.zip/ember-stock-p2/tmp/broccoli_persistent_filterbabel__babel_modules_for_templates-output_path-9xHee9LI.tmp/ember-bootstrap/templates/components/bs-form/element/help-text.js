define("ember-bootstrap/templates/components/bs-form/element/help-text", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "zZVUZt6L", "block": "{\"symbols\":[],\"statements\":[[1,[21,\"text\"],false]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-form/element/help-text.hbs" } });
});