define("ember-bootstrap/templates/components/bs-form", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "PIjqgOi6", "block": "{\"symbols\":[\"&default\"],\"statements\":[[14,1,[[27,\"hash\",null,[[\"element\",\"group\"],[[27,\"component\",[\"bs-form/element\"],[[\"model\",\"formLayout\",\"horizontalLabelGridClass\",\"showAllValidations\",\"onChange\"],[[23,[\"model\"]],[23,[\"formLayout\"]],[23,[\"horizontalLabelGridClass\"]],[23,[\"showAllValidations\"]],[27,\"action\",[[22,0,[]],\"change\"],null]]]],[27,\"component\",[\"bs-form/group\"],[[\"formLayout\"],[[23,[\"formLayout\"]]]]]]]]]]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-form.hbs" } });
});