define("ember-bootstrap/templates/components/bs-modal/header/close", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "j9kGUdCW", "block": "{\"symbols\":[],\"statements\":[[7,\"span\"],[11,\"aria-hidden\",\"true\"],[9],[0,\"×\"],[10]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-modal/header/close.hbs" } });
});