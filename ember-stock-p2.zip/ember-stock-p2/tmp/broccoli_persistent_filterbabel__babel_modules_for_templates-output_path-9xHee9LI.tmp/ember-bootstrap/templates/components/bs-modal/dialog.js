define("ember-bootstrap/templates/components/bs-modal/dialog", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "2dPoOnnB", "block": "{\"symbols\":[\"&default\"],\"statements\":[[7,\"div\"],[12,\"class\",[28,[\"modal-dialog \",[21,\"sizeClass\"],\" \",[27,\"if\",[[23,[\"centered\"]],\"modal-dialog-centered\"],null]]]],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"modal-content\"],[9],[0,\"\\n    \"],[14,1],[0,\"\\n  \"],[10],[0,\"\\n\"],[10]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-modal/dialog.hbs" } });
});