define("ember-bootstrap/templates/components/bs-dropdown", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "Ga40FHqO", "block": "{\"symbols\":[\"&default\"],\"statements\":[[14,1,[[27,\"hash\",null,[[\"button\",\"toggle\",\"menu\",\"isOpen\"],[[27,\"component\",[\"bs-dropdown/button\"],[[\"dropdown\",\"onClick\"],[[22,0,[]],[27,\"action\",[[22,0,[]],\"toggleDropdown\"],null]]]],[27,\"component\",[\"bs-dropdown/toggle\"],[[\"dropdown\",\"inNav\",\"onClick\"],[[22,0,[]],[23,[\"inNav\"]],[27,\"action\",[[22,0,[]],\"toggleDropdown\"],null]]]],[27,\"component\",[\"bs-dropdown/menu\"],[[\"isOpen\",\"direction\",\"inNav\",\"toggleElement\"],[[23,[\"isOpen\"]],[23,[\"direction\"]],[23,[\"inNav\"]],[23,[\"toggleElement\"]]]]],[23,[\"isOpen\"]]]]]]]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-dropdown.hbs" } });
});