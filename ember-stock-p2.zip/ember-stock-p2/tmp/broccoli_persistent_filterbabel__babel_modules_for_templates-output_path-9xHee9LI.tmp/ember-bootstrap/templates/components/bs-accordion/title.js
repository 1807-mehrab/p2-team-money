define("ember-bootstrap/templates/components/bs-accordion/title", ["exports"], function (exports) {
  "use strict";

  exports.__esModule = true;
  exports.default = Ember.HTMLBars.template({ "id": "uQYI689D", "block": "{\"symbols\":[\"&default\"],\"statements\":[[7,\"h5\"],[11,\"class\",\"mb-0\"],[9],[0,\"\\n  \"],[7,\"button\"],[11,\"class\",\"btn btn-link\"],[11,\"type\",\"button\"],[9],[0,\"\\n    \"],[14,1],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"]],\"hasEval\":false}", "meta": { "moduleName": "ember-bootstrap/templates/components/bs-accordion/title.hbs" } });
});